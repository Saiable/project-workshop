let str = `<ul id="J_freeChampionContainer">
<li class="week-free-item">
  <img src="//game.gtimg.cn/images/lol/act/img/champion/Ryze.png" alt="瑞兹" width="46" height="46">
  <a href="/data/info-defail.shtml?id=13" onclick="PTTSendClick('version','version-weekfree-Ryze','瑞兹')" class="herf-mask" target="_blank" title="瑞兹"></a>
</li>

<li class="week-free-item">
  <img src="//game.gtimg.cn/images/lol/act/img/champion/Sivir.png" alt="希维尔" width="46" height="46">
  <a href="/data/info-defail.shtml?id=15" onclick="PTTSendClick('version','version-weekfree-Sivir','希维尔')" class="herf-mask" target="_blank" title="希维尔"></a>
</li>

<li class="week-free-item">
  <img src="//game.gtimg.cn/images/lol/act/img/champion/Teemo.png" alt="提莫" width="46" height="46">
  <a href="/data/info-defail.shtml?id=17" onclick="PTTSendClick('version','version-weekfree-Teemo','提莫')" class="herf-mask" target="_blank" title="提莫"></a>
</li>

<li class="week-free-item">
  <img src="//game.gtimg.cn/images/lol/act/img/champion/Nunu.png" alt="努努和威朗普" width="46" height="46">
  <a href="/data/info-defail.shtml?id=20" onclick="PTTSendClick('version','version-weekfree-Nunu','努努和威朗普')" class="herf-mask" target="_blank" title="努努和威朗普"></a>
</li>

<li class="week-free-item">
  <img src="//game.gtimg.cn/images/lol/act/img/champion/MissFortune.png" alt="厄运小姐" width="46" height="46">
  <a href="/data/info-defail.shtml?id=21" onclick="PTTSendClick('version','version-weekfree-MissFortune','厄运小姐')" class="herf-mask" target="_blank" title="厄运小姐"></a>
</li>

<li class="week-free-item">
  <img src="//game.gtimg.cn/images/lol/act/img/champion/Ashe.png" alt="艾希" width="46" height="46">
  <a href="/data/info-defail.shtml?id=22" onclick="PTTSendClick('version','version-weekfree-Ashe','艾希')" class="herf-mask" target="_blank" title="艾希"></a>
</li>

<li class="week-free-item">
  <img src="//game.gtimg.cn/images/lol/act/img/champion/Tryndamere.png" alt="泰达米尔" width="46" height="46">
  <a href="/data/info-defail.shtml?id=23" onclick="PTTSendClick('version','version-weekfree-Tryndamere','泰达米尔')" class="herf-mask" target="_blank" title="泰达米尔"></a>
</li>

<li class="week-free-item">
  <img src="//game.gtimg.cn/images/lol/act/img/champion/Karma.png" alt="卡尔玛" width="46" height="46">
  <a href="/data/info-defail.shtml?id=43" onclick="PTTSendClick('version','version-weekfree-Karma','卡尔玛')" class="herf-mask" target="_blank" title="卡尔玛"></a>
</li>

<li class="week-free-item">
  <img src="//game.gtimg.cn/images/lol/act/img/champion/Nidalee.png" alt="奈德丽" width="46" height="46">
  <a href="/data/info-defail.shtml?id=76" onclick="PTTSendClick('version','version-weekfree-Nidalee','奈德丽')" class="herf-mask" target="_blank" title="奈德丽"></a>
</li>

<li class="week-free-item">
  <img src="//game.gtimg.cn/images/lol/act/img/champion/Pantheon.png" alt="潘森" width="46" height="46">
  <a href="/data/info-defail.shtml?id=80" onclick="PTTSendClick('version','version-weekfree-Pantheon','潘森')" class="herf-mask" target="_blank" title="潘森"></a>
</li>

<li class="week-free-item">
  <img src="//game.gtimg.cn/images/lol/act/img/champion/Garen.png" alt="盖伦" width="46" height="46">
  <a href="/data/info-defail.shtml?id=86" onclick="PTTSendClick('version','version-weekfree-Garen','盖伦')" class="herf-mask" target="_blank" title="盖伦"></a>
</li>

<li class="week-free-item">
  <img src="//game.gtimg.cn/images/lol/act/img/champion/Ahri.png" alt="阿狸" width="46" height="46">
  <a href="/data/info-defail.shtml?id=103" onclick="PTTSendClick('version','version-weekfree-Ahri','阿狸')" class="herf-mask" target="_blank" title="阿狸"></a>
</li>

<li class="week-free-item">
  <img src="//game.gtimg.cn/images/lol/act/img/champion/Volibear.png" alt="沃利贝尔" width="46" height="46">
  <a href="/data/info-defail.shtml?id=106" onclick="PTTSendClick('version','version-weekfree-Volibear','沃利贝尔')" class="herf-mask" target="_blank" title="沃利贝尔"></a>
</li>

<li class="week-free-item">
  <img src="//game.gtimg.cn/images/lol/act/img/champion/Rengar.png" alt="雷恩加尔" width="46" height="46">
  <a href="/data/info-defail.shtml?id=107" onclick="PTTSendClick('version','version-weekfree-Rengar','雷恩加尔')" class="herf-mask" target="_blank" title="雷恩加尔"></a>
</li>

<li class="week-free-item">
  <img src="//game.gtimg.cn/images/lol/act/img/champion/Lulu.png" alt="璐璐" width="46" height="46">
  <a href="/data/info-defail.shtml?id=117" onclick="PTTSendClick('version','version-weekfree-Lulu','璐璐')" class="herf-mask" target="_blank" title="璐璐"></a>
</li>

<li class="week-free-item">
  <img src="//game.gtimg.cn/images/lol/act/img/champion/Taliyah.png" alt="塔莉垭" width="46" height="46">
  <a href="/data/info-defail.shtml?id=163" onclick="PTTSendClick('version','version-weekfree-Taliyah','塔莉垭')" class="herf-mask" target="_blank" title="塔莉垭"></a>
</li>

<li class="week-free-item">
  <img src="//game.gtimg.cn/images/lol/act/img/champion/Azir.png" alt="阿兹尔" width="46" height="46">
  <a href="/data/info-defail.shtml?id=268" onclick="PTTSendClick('version','version-weekfree-Azir','阿兹尔')" class="herf-mask" target="_blank" title="阿兹尔"></a>
</li>
</ul>`;

let data = [];
str.replace(/\n/g, '').replace(/<li (?:[^>]+)>((?:(?!<\/li>).)+)/g, (_, $1) => {
  let name, href, pic;
  [, pic = '', name = ''] = /<img src="([^"]+)" alt="([^"]+)"/.exec($1) || [];
  [, href = ''] = /<a href="([^"]+)"/.exec($1) || [];

  pic && !pic.includes('http') ? pic = 'https:' + pic : null;

  `<li class="week-free-item">
  <img src="//game.gtimg.cn/images/lol/act/img/champion/Ryze.png" alt="瑞兹" width="46" height="46">
  <a href="/data/info-defail.shtml?id=13" onclick="PTTSendClick('version','version-weekfree-Ryze','瑞兹')" class="herf-mask" target="_blank" title="瑞兹"></a>
</li>`

  // 存储数据
  data.push({
    name,
    href,
    pic
  });
});

let fs = require('fs');
fs.writeFileSync('./1.json', JSON.stringify(data));