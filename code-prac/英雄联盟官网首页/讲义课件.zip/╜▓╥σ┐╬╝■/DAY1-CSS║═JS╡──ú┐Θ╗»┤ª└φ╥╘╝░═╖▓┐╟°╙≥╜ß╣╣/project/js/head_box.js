// 导入某个模块，并且使用其暴露的方法
import http from './http.js';