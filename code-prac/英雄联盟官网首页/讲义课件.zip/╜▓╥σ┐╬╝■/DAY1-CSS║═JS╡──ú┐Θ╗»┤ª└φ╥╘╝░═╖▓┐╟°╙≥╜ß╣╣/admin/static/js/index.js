import './header_box.js';
import './swiper_container_home.js';
import './news_box.js';