let str = `<ul class="fanart-left-content" id="J_fanartContainer">
<li>
  <a href="//tr.lol.qq.com/fanart/detail.html?contentId=67790" target="_blank" title="血月之主——劫" onclick="PTTSendClick('fanart','fanart-item67790','血月之主——劫');">
    <img class="fanart-img" id="fanart0" src="https://shp.qpic.cn/cms_pic/2680554389/513f9f3bd1b6e284b0340cec5852f2a8/258" alt="血月之主——劫">
  </a>
  <!--hover-->
  <div class="innerhover-bottom">
    <h4 class="p1">
      <a href="//tr.lol.qq.com/fanart/detail.html?contentId=67790" target="_blank" onclick="PTTSendClick('fanart','fanart-item67790','血月之主——劫');">
        血月之主——劫
      </a>
    </h4>
    <p class="p2">
      <a class="a1" href="//tr.lol.qq.com/fanart/space.html?openId=5JHqej7de71jZB7WWji4DA==" target="_blank" onclick="PTTSendClick('fanart','fanart-item67790','不语');">
        <img src="" width="22" height="22" alt="不语">不语
      </a>
      <a class="a2" href="javascript:" data-zan="67790" onclick="PTTSendClick('fanart','fanart-item67790','赞');">
        <i class="icon-666"></i><span class="number">12</span><span class="tip">+1</span>
      </a>
    </p>
  </div>
</li>

<li>
  <a href="//tr.lol.qq.com/fanart/detail.html?contentId=67789" target="_blank" title="月升之时 千珏" onclick="PTTSendClick('fanart','fanart-item67789','月升之时 千珏');">
    <img class="fanart-img" id="fanart1" src="https://shp.qpic.cn/cms_pic/2600146797/c70b54e024a20ff1b5b2603a2058f428/258" alt="月升之时 千珏">
  </a>
  <!--hover-->
  <div class="innerhover-bottom">
    <h4 class="p1">
      <a href="//tr.lol.qq.com/fanart/detail.html?contentId=67789" target="_blank" onclick="PTTSendClick('fanart','fanart-item67789','月升之时 千珏');">
        月升之时 千珏
      </a>
    </h4>
    <p class="p2">
      <a class="a1" href="//tr.lol.qq.com/fanart/space.html?openId=bXe3htjbQEBSFbJTetFxew==" target="_blank" onclick="PTTSendClick('fanart','fanart-item67789','雨生种');">
        <img src="" width="22" height="22" alt="雨生种">雨生种
      </a>
      <a class="a2" href="javascript:" data-zan="67789" onclick="PTTSendClick('fanart','fanart-item67789','赞');">
        <i class="icon-666"></i><span class="number">10</span><span class="tip">+1</span>
      </a>
    </p>
  </div>
</li>

<li>
  <a href="//tr.lol.qq.com/fanart/detail.html?contentId=67786" target="_blank" title="捣蛋鬼提莫" onclick="PTTSendClick('fanart','fanart-item67786','捣蛋鬼提莫');">
    <img class="fanart-img" id="fanart2" src="https://shp.qpic.cn/cms_pic/2580441255/1be34310457b3d514fbfedd07586cd70/258" alt="捣蛋鬼提莫">
  </a>
  <!--hover-->
  <div class="innerhover-bottom">
    <h4 class="p1">
      <a href="//tr.lol.qq.com/fanart/detail.html?contentId=67786" target="_blank" onclick="PTTSendClick('fanart','fanart-item67786','捣蛋鬼提莫');">
        捣蛋鬼提莫
      </a>
    </h4>
    <p class="p2">
      <a class="a1" href="//tr.lol.qq.com/fanart/space.html?openId=iHQd5BF8UCiStAjNs1gVrw==" target="_blank" onclick="PTTSendClick('fanart','fanart-item67786','回家吃地三鲜');">
        <img src="" width="22" height="22" alt="回家吃地三鲜">回家吃地三鲜
      </a>
      <a class="a2" href="javascript:" data-zan="67786" onclick="PTTSendClick('fanart','fanart-item67786','赞');">
        <i class="icon-666"></i><span class="number">2</span><span class="tip">+1</span>
      </a>
    </p>
  </div>
</li>

<li>
  <a href="//tr.lol.qq.com/fanart/detail.html?contentId=67785" target="_blank" title="女帝的新衣" onclick="PTTSendClick('fanart','fanart-item67785','女帝的新衣');">
    <img class="fanart-img" id="fanart3" src="https://shp.qpic.cn/cms_pic/2670351422/0b47c4116ec106ca3e53580bc453979b/258" alt="女帝的新衣">
  </a>
  <!--hover-->
  <div class="innerhover-bottom">
    <h4 class="p1">
      <a href="//tr.lol.qq.com/fanart/detail.html?contentId=67785" target="_blank" onclick="PTTSendClick('fanart','fanart-item67785','女帝的新衣');">
        女帝的新衣
      </a>
    </h4>
    <p class="p2">
      <a class="a1" href="//tr.lol.qq.com/fanart/space.html?openId=40QiVH2bS9VPDxJcifx9Fw==" target="_blank" onclick="PTTSendClick('fanart','fanart-item67785','肥皂泡');">
        <img src="" width="22" height="22" alt="肥皂泡">肥皂泡
      </a>
      <a class="a2" href="javascript:" data-zan="67785" onclick="PTTSendClick('fanart','fanart-item67785','赞');">
        <i class="icon-666"></i><span class="number">1</span><span class="tip">+1</span>
      </a>
    </p>
  </div>
</li>

<li>
  <a href="//tr.lol.qq.com/fanart/detail.html?contentId=67784" target="_blank" title="很久前摸的萨勒芬妮" onclick="PTTSendClick('fanart','fanart-item67784','很久前摸的萨勒芬妮');">
    <img class="fanart-img" id="fanart4" src="https://shp.qpic.cn/cms_pic/2600377171/ba3f033f7a16e7fb3fdff85e4bd12cd6/258" alt="很久前摸的萨勒芬妮">
  </a>
  <!--hover-->
  <div class="innerhover-bottom">
    <h4 class="p1">
      <a href="//tr.lol.qq.com/fanart/detail.html?contentId=67784" target="_blank" onclick="PTTSendClick('fanart','fanart-item67784','很久前摸的萨勒芬妮');">
        很久前摸的萨勒芬妮
      </a>
    </h4>
    <p class="p2">
      <a class="a1" href="//tr.lol.qq.com/fanart/space.html?openId=RbT0QQ6S5CUvyJVsIE00Rg==" target="_blank" onclick="PTTSendClick('fanart','fanart-item67784','瑞安·泰鸽□');">
        <img src="" width="22" height="22" alt="瑞安·泰鸽□">瑞安·泰鸽□
      </a>
      <a class="a2" href="javascript:" data-zan="67784" onclick="PTTSendClick('fanart','fanart-item67784','赞');">
        <i class="icon-666"></i><span class="number">1</span><span class="tip">+1</span>
      </a>
    </p>
  </div>
</li>

<li>
  <a href="//tr.lol.qq.com/fanart/detail.html?contentId=67783" target="_blank" title="蒸汽机器人 布里茨（战损版）" onclick="PTTSendClick('fanart','fanart-item67783','蒸汽机器人 布里茨（战损版）');">
    <img class="fanart-img" id="fanart5" src="https://shp.qpic.cn/cms_pic/2650002051/80f368e51f4e8f0bf1aab9aa1938b3d9/258" alt="蒸汽机器人 布里茨（战损版）">
  </a>
  <!--hover-->
  <div class="innerhover-bottom">
    <h4 class="p1">
      <a href="//tr.lol.qq.com/fanart/detail.html?contentId=67783" target="_blank" onclick="PTTSendClick('fanart','fanart-item67783','蒸汽机器人 布里茨（战损版）');">
        蒸汽机器人 布里茨（战损版）
      </a>
    </h4>
    <p class="p2">
      <a class="a1" href="//tr.lol.qq.com/fanart/space.html?openId=ASi3WM4waiuDaHwvKuZgwA==" target="_blank" onclick="PTTSendClick('fanart','fanart-item67783','兔几上将');">
        <img src="" width="22" height="22" alt="兔几上将">兔几上将
      </a>
      <a class="a2" href="javascript:" data-zan="67783" onclick="PTTSendClick('fanart','fanart-item67783','赞');">
        <i class="icon-666"></i><span class="number">0</span><span class="tip">+1</span>
      </a>
    </p>
  </div>
</li>

<li>
  <a href="//tr.lol.qq.com/fanart/detail.html?contentId=67779" target="_blank" title="拉克丝" onclick="PTTSendClick('fanart','fanart-item67779','拉克丝');">
    <img class="fanart-img" id="fanart6" src="https://shp.qpic.cn/cms_pic/2570329613/c755282739bf51c6d5d07ed12031beb7/258" alt="拉克丝">
  </a>
  <!--hover-->
  <div class="innerhover-bottom">
    <h4 class="p1">
      <a href="//tr.lol.qq.com/fanart/detail.html?contentId=67779" target="_blank" onclick="PTTSendClick('fanart','fanart-item67779','拉克丝');">
        拉克丝
      </a>
    </h4>
    <p class="p2">
      <a class="a1" href="//tr.lol.qq.com/fanart/space.html?openId=vitFJaROEbwdxPgYNW37oA==" target="_blank" onclick="PTTSendClick('fanart','fanart-item67779','莫大杆');">
        <img src="" width="22" height="22" alt="莫大杆">莫大杆
      </a>
      <a class="a2" href="javascript:" data-zan="67779" onclick="PTTSendClick('fanart','fanart-item67779','赞');">
        <i class="icon-666"></i><span class="number">8</span><span class="tip">+1</span>
      </a>
    </p>
  </div>
</li>

<li>
  <a href="//tr.lol.qq.com/fanart/detail.html?contentId=67772" target="_blank" title="neeko" onclick="PTTSendClick('fanart','fanart-item67772','neeko');">
    <img class="fanart-img" id="fanart7" src="https://shp.qpic.cn/cms_pic/2520057091/c2c23522c24c16b9ff0c883cea9ff165/258" alt="neeko">
  </a>
  <!--hover-->
  <div class="innerhover-bottom">
    <h4 class="p1">
      <a href="//tr.lol.qq.com/fanart/detail.html?contentId=67772" target="_blank" onclick="PTTSendClick('fanart','fanart-item67772','neeko');">
        neeko
      </a>
    </h4>
    <p class="p2">
      <a class="a1" href="//tr.lol.qq.com/fanart/space.html?openId=84dWf/xzgHA0OrpyIYblFw==" target="_blank" onclick="PTTSendClick('fanart','fanart-item67772','Harold-AN');">
        <img src="" width="22" height="22" alt="Harold-AN">Harold-AN
      </a>
      <a class="a2" href="javascript:" data-zan="67772" onclick="PTTSendClick('fanart','fanart-item67772','赞');">
        <i class="icon-666"></i><span class="number">3</span><span class="tip">+1</span>
      </a>
    </p>
  </div>
</li>
</ul>`;

let data = [];
str.replace(/\n/g, '').replace(/<li>((?:(?!<\/li>).)+)/g, (_, $1) => {
    let pic, title, href, author, authorHref, fabulous;
    [, pic = '', title = ''] = /<img class="fanart-img" id="(?:[^"]+)" src="([^"]+)" alt="([^"]+)">/.exec($1) || [];
    [, href = ''] = /<a href="([^"]+)"/.exec($1) || [];
    [, authorHref = '', author = ''] = /<a class="a1" href="([^"]+)" target="_blank" onclick="PTTSendClick\('(?:[^']+)','(?:[^']+)','([^']+)'\);"/.exec($1) || [];
    [, fabulous] = /<span class="number">([^<]+)<\/span>/.exec($1) || [];

    pic && !pic.includes('http') ? pic = 'https:' + pic : null;
    href && !href.includes('http') ? href = 'https:' + href : null;
    authorHref && !authorHref.includes('http') ? authorHref = 'https:' + authorHref : null;

    // 存储数据
    data.push({
        pic,
        title,
        href,
        author,
        authorHref,
        fabulous
    });
});

let fs = require('fs');
fs.writeFileSync('./1.json', JSON.stringify(data));