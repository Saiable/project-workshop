import Iscroll from 'iscroll';
import axios from 'axios';
import qs from 'qs';

window.Iscroll = Iscroll;
window.qs = qs;
window.axios = axios;