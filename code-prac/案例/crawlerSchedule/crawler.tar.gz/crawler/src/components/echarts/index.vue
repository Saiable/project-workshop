<template>
    <div class="container">
        <div class="chartA" ref="chartA"></div>
    </div>
</template>
<script>
export default {
    name: "echarts",
    data() {
        return {
            optionA: {
                xAxis: {
                    type: "category",
                    data: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
                },
                yAxis: {
                    type: "value",
                },
                series: [
                    {
                        data: [820, 932, 901, 934, 1290, 1330, 1320],
                        type: "line",
                    },
                ],
            },
        };
    },
    mounted() {
        let myChart = this.$echarts.init(this.$refs.chartA)
        // console.log(myChart)
        myChart.setOption(this.optionA)
    },
};
</script>

<style scoped lang="less">
.container {
    .chartA {
        width: 450px;
        height: 200px;
    }
}
</style>
