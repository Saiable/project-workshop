import Vue from 'vue'
import VueRouter from 'vue-router'
import HomeView from '../views/HomeView.vue'
let originPush = VueRouter.prototype.push
VueRouter.prototype.push = function (location, resolve, reject) {
    if (resolve && reject) {
        originPush.call(this, location, resolve, reject)
    } else {
        originPush.call(
            this,
            location,
            () => {
            },
            () => {
            })
    }
}

let originReplace = VueRouter.prototype.replace
VueRouter.prototype.replace = function (location, resolve, reject) {
    if (resolve && reject) {
        originReplace.call(this, location, resolve, reject)
    } else {
        originReplace.call(
            this,
            location,
            () => {
            },
            () => {
            })
    }
}
Vue.use(VueRouter)

const routes = [
  {
    path: '/about',
    name: 'about',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/AboutView.vue')
  },
  {
    path:'/test',
    name: 'test',
    component: () => import('@/test/index.vue')
  },
  {
    path:'/echarts',
    name: 'echarts',
    component: () => import('@/components/echarts/index.vue')
  },
  {
    path:'/home',
    name: 'home',
    component: () => import('@/layout/home/index.vue'),
    children: [
      {
        name:'schedule',
        path: 'schedule',
        component: () => import('@/layout/home/schedule/index.vue')
      }
    ]
  }
]

const router = new VueRouter({
  routes
})

export default router
