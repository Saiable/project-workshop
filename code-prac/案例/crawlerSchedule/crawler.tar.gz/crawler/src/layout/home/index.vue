<template>
  <div class="container">
    <div class="sidebar">
      <div class="header">
        <div class="header-top">
          <span class="iconfont icon-tupianpachong-02"></span>
          <span class="text">spider.mon</span>
          <span class="iconfont icon-qiehuanbaogaomingxi"></span>
        </div>
        <div class="header-content">
          <ul class="outer">
            <li class="item" @click="toIndex()">
              Jobs
              <span class="iconfont icon-shouye"></span>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="content">
      <div class="schedule">
        <router-view></router-view>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "home",
  data() {
    return {};
  },
  methods: {
    toIndex() {
      this.$router.push({
        name: "schedule",
      });
    },
  },
};
</script>
<style lang="less" scoped>
.container {
  display: flex;

  .sidebar {
    width: 250px;
    height: 100vh;
    background: #30426a;

    .header-top {
      padding: 15px 25px;
      color: #fff;

      .iconfont {
        font-size: 24px;
        margin-right: 5px;
      }

      .text {
        font-size: 20px;
      }

      .icon-qiehuanbaogaomingxi {
        font-size: 20px;
        float: right;
      }
    }

    .header-content {
      border-left: 4px solid #fff;
      color: #fff;
      a {
        text-decoration: none;
        color: #b2bfdc;
      }

      .outer {
        padding: 0 30px;
        width: 100%;
        height: 100%;
        cursor: pointer;

        &:hover {
          background-color: #2d3e63;
          a {
            color: #fff;
          }
        }
      }

      .item {
        width: 100%;
        height: 36px;
        line-height: 36px;
        font-size: 16px;
        color: #b2bfdc;

        &:hover {
          color: #fff;
        }

        .iconfont {
          float: right;
          font-size: 18px;
        }
      }
    }
  }

  .content {
    width: calc(100vw - 250px);
    height: 100vh;
    background-color: #f3f3f3;

    .schedule {
      width: 100%;
      height: calc(100vh - 60px);
    }
  }
}
</style>
>
