<template>
  <div class="container">
    <div class="container-header">
      <div class="text">
        {{ name }}
        <i
          class="iconfont icon-shuaxin1"
          @click="refreshData()"
          title="Refresh"
        ></i>
      </div>
      <div class="account">
        <i class="iconfont icon-1zhanghu"></i>
        <span>Admin</span>
      </div>
    </div>

    <div class="outer">
      <div class="outer-container">
        <div class="header">
          <i class="iconfont icon-jihuatiaodu"></i>
          Jobs
        </div>
        <div class="control">
          <ul class="group">
            <li class="item">
              <i class="iconfont icon-daochu1024-15"></i>
              <span>Start</span>
            </li>
            <li class="item">
              <i class="iconfont icon-lujing"></i>
              <span>Stop</span>
            </li>
            <li class="item">
              <i class="iconfont icon-shuaxin1"></i>
              <span>Restart</span>
            </li>
            <li class="item">
              <i class="iconfont icon-zanting"></i>
              <span>Pause</span>
            </li>
            <li class="item">
              <i class="iconfont icon-daochu1024-15"></i>
              <span>Resume</span>
            </li>
            <li class="item">
              <i class="iconfont icon-shanchu"></i>
              <span>Remove</span>
            </li>
          </ul>
          <div class="item item-add">
            <i class="iconfont icon-add"></i>
            <span>Add Jobs</span>
          </div>
        </div>
        <div class="search">
          <i class="iconfont icon-sousuotianchong"></i>
          <input type="text" class="search-input" placeholder="Search ..." />
        </div>
        <div class="list">
          
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import {getAllSpider} from '@/api/crawler.js'
export default {
  name: "schedule",
  data() {
    return {
      name: "Jobs List",
    };
  },
  methods: {
    refreshData() {
      console.log("refreshData");
    },
  },
  mounted() {
    getAllSpider().then((res) => {
      console.log(res)
    })
  }
};
</script>
<style lang="less" scoped>
.container {
  display: flex;
  flex-direction: column;
  .container-header {
    position: relative;
    width: 100%;
    height: 60px;
    background-color: #fff;
    // margin-bottom: 24px;
    .text {
      height: 60px;
      line-height: 60px;
      margin-left: 24px;
      font-size: 24px;
      font-weight: 300;
      .iconfont {
        color: #30426a;
        cursor: pointer;
        &:hover {
          color: #1e2b47;
        }
      }
    }
    .account {
      position: absolute;
      margin-right: 24px;
      top: 50%;
      transform: translateY(-50%);
      right: 0;
      .iconfont {
        margin-right: 5px;
      }
    }
  }
  .outer {
    position: relative;
    width: 100%;
    padding-right: 10px;
    margin-top: 24px;
    .outer-container {
      position: absolute;
      left: 24px;
      width: calc(100vw - 300px);
      box-shadow: 0px 0px 2px 1px rgba(95, 94, 94, 0.2);
    }
    .header {
      height: 45px;
      padding: 0 20px;
      background-color: #f3f3f3;
      font-size: 20px;
      line-height: 45px;
      color: #767676;
      .iconfont {
        font-size: 16px;
      }
    }
    .control {
      //   display: flex;
      position: relative;
      height: 50px;
      width: 100%;
      line-height: 50px;
      background-color: #fff;
      padding: 0 20px;
      border-bottom: 1px solid rgba(190, 190, 190, 0.575);

      .group {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        display: flex;
        // float: left;

        height: 28px;
        line-height: 28px;
        .item {
          padding: 0 8px;
          color: #fff;

          .iconfont {
            margin-right: 4px;
          }
        }
        .item:nth-child(1) {
          border-top-left-radius: 4px;
          border-bottom-left-radius: 4px;
          background-color: #5cb85c;
        }
        .item:nth-child(2) {
          background-color: #d9534f;
        }
        .item:nth-child(3) {
          background-color: #337ab7;
        }
        .item:nth-child(4) {
          background-color: #337ab7;
        }
        .item:nth-child(5) {
          background-color: #337ab7;
        }
        .item:nth-child(6) {
          border-top-right-radius: 4px;
          border-bottom-right-radius: 4px;
          background-color: #d9534f;
        }
      }
      .item-add {
        // float: right;
        position: absolute;
        right: 0;
        top: 50%;
        transform: translateY(-50%);
        height: 28px;
        padding: 0 8px;
        margin-right: 20px;
        line-height: 28px;
        background-color: #337ab7;
        border-radius: 4px;
        color: #fff;
        .iconfont {
          margin-right: 4px;
        }
      }
    }
  }
  .search {
    display: flex;
    height: 38px;
    line-height: 38px;
    padding: 0 24px;
    background-color: #fff;
    border-bottom: 1px solid rgba(190, 190, 190, 0.575);

    .search-input {
      width: 100%;
      background-color: #fff;
      margin-left: 5px;
      border: none;
      outline: none;
      letter-spacing: 1px;
      font-size: 18px;
    }
  }
}
</style>