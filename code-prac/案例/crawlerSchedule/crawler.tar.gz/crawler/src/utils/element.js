import Vue from 'vue'
import { Button, Row } from 'element-ui'; // 注意引入的时候，是没有`el`的，然后第一个字母大写
Vue.component(Button.name, Button);  // 第一个参数，就是自定义的一个名称
Vue.component(Row.name, Row);